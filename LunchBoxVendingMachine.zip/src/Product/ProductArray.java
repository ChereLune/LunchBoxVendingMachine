package Product;

import java.util.ArrayList;
import java.util.List;

public class ProductArray {
	public static List<Product> productList = new ArrayList<Product>();
}