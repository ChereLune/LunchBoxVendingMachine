package Machine;

public class MachineMain {
	
	public static void main(String[] args) {
		new MachineFront();
	}
}